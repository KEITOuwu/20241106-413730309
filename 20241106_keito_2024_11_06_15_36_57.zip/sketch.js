function setup() {
  createCanvas(windowWidth, windowHeight);
   background("#C7EAE4");
}
var w =100
function draw() {
  background("#C7EAE4");
  rectMode(CENTER) //設定方框中心點為方框的座標點
  noFill()  //以下畫圓或方形都不要填滿顏色
  for(var x=50;x<=width+50;x=x+w){
     //畫圓,設定線框顏色與線條粗細
  stroke("#F5A65B")
  strokeWeight(2)
  ellipse(x,50,w) 
    //畫方框,設定線框顏色與線條粗細
    stroke("#5e6472")
  strokeWeight(2)
  rect(x,50,w) 
  }
}